/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ng-multiselect-dropdown" />
export * from './public_api';
